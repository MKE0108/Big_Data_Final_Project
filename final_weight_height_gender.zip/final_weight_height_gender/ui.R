library(shiny)
library(plotly)

# Define UI for application
ui <- fluidPage(
  # Application title
  titlePanel("運動員身體數據"),
  
  # Sidebar with a selection input for seasons
  sidebarLayout(
    sidebarPanel(
      radioButtons('unit', '選擇數據範圍', c("全季運動"='all',"前五後五" = 'five', "選定運動"='selectS'), selected = "five", inline = TRUE),
      selectInput("seasonSelect",
                  "Select Season:",
                  choices = c("Summer", "Winter")),
      # This second selectInput will update based on the first selectInput's choice
      uiOutput("dynamicSelect")
    ),
    
    # Main panel for displaying the plotly plot
    mainPanel(
      uiOutput("main")  
    )
  )
)
