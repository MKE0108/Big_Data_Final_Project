x = read.csv("athlete_events.csv", stringsAsFactors = FALSE)

#------------all Height----------------
ASHfiltered_data <- x %>% filter(!is.na(Height), Season == "Summer") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup()

ASHfiltered_data <- ASHfiltered_data %>%
  group_by(Sport) %>%
  mutate(HeightQ1 = quantile(Height, 0.25),
         HeightQ3 = quantile(Height, 0.75),
         HeightIQR = HeightQ3 - HeightQ1) %>%
  filter(Height >= (HeightQ1 - 1.5 * HeightIQR) & Height <= (HeightQ3 + 1.5 * HeightIQR)) %>%
  ungroup()

AWHfiltered_data <- x %>% filter(!is.na(Height), Season == "Winter") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup()

AWHfiltered_data <- AWHfiltered_data %>%
  group_by(Sport) %>%
  mutate(HeightQ1 = quantile(Height, 0.25),
         HeightQ3 = quantile(Height, 0.75),
         HeightIQR = HeightQ3 - HeightQ1) %>%
  filter(Height >= (HeightQ1 - 1.5 * HeightIQR) & Height <= (HeightQ3 + 1.5 * HeightIQR)) %>%
  ungroup()

ASHplot <- plot_ly(ASHfiltered_data, y = ~Height, color = ~Sport, type = "box") %>%
  layout(title = "各運動選手身高的四分位數圖",
         yaxis = list(title = "身高 (cm)"),
         xaxis = list(title = "運動類型"))

AWHplot <- plot_ly(AWHfiltered_data, y = ~Height, color = ~Sport, type = "box") %>%
  layout(title = "各運動選手身高的四分位數圖",
         yaxis = list(title = "身高 (cm)"),
         xaxis = list(title = "運動類型"))
#------------all Height----------------

#------------all weight----------------

ASWfiltered_data <- x %>% filter(!is.na(Weight), Season == "Summer") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup()

ASWfiltered_data <- ASWfiltered_data %>%
  group_by(Sport) %>%
  mutate(WeightQ1 = quantile(Weight, 0.25),
         WeightQ3 = quantile(Weight, 0.75),
         WeightIQR = WeightQ3 - WeightQ1) %>%
  filter(Weight >= (WeightQ1 - 1.5 * WeightIQR) & Weight <= (WeightQ3 + 1.5 * WeightIQR)) %>%
  ungroup()

AWWfiltered_data <- x %>% filter(!is.na(Weight), Season == "Winter") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup()

AWWfiltered_data <- AWWfiltered_data %>%
  group_by(Sport) %>%
  mutate(WeightQ1 = quantile(Weight, 0.25),
         WeightQ3 = quantile(Weight, 0.75),
         WeightIQR = WeightQ3 - WeightQ1) %>%
  filter(Weight >= (WeightQ1 - 1.5 * WeightIQR) & Weight <= (WeightQ3 + 1.5 * WeightIQR)) %>%
  ungroup()

ASWplot <- plot_ly(ASWfiltered_data, y = ~Weight, color = ~Sport, type = "box") %>%
  layout(title = "各運動選手體重四分位數圖",
         yaxis = list(title = "體重 (kg)"),
         xaxis = list(title = "運動類型"))

AWWplot <- plot_ly(AWWfiltered_data, y = ~Weight, color = ~Sport, type = "box") %>%
  layout(title = "各運動選手體重四分位數圖",
         yaxis = list(title = "體重 (kg)"),
         xaxis = list(title = "運動類型"))

#------------all weight----------------


#------------five Height----------------

Wfiltered_data <- x %>%
  filter(!is.na(Height), Season == "Winter") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup()

# 計算IQR並去除極端值
Wfiltered_data <- Wfiltered_data %>%
  group_by(Sport) %>%
  mutate(HeightQ1 = quantile(Height, 0.25),
         HeightQ3 = quantile(Height, 0.75),
         HeightIQR = HeightQ3 - HeightQ1) %>%
  filter(Height >= (HeightQ1 - 1.5 * HeightIQR) & Height <= (HeightQ3 + 1.5 * HeightIQR)) %>%
  ungroup()

# 計算各運動的平均身高
FFtop_sports_by_height <- Wfiltered_data %>%
  group_by(Sport) %>%
  summarize(Average_Height = mean(Height, na.rm = TRUE)) %>%
  arrange(desc(Average_Height)) %>%
  slice_head(n = 5)  # 選出平均身高前五的運動

# 從原始數據中篩選出這些運動的數據
FFtop_sports_data <- Wfiltered_data %>%
  filter(Sport %in% FFtop_sports_by_height$Sport)



LFtop_sports_by_height <- Wfiltered_data %>%
  group_by(Sport) %>%
  summarize(Average_Height = mean(Height, na.rm = TRUE)) %>%
  arrange(Average_Height) %>%
  slice_head(n = 5)  # 選出平均身高前五的運動

# 從原始數據中篩選出這些運動的數據
LFtop_sports_data <- Wfiltered_data %>%
  filter(Sport %in% LFtop_sports_by_height$Sport)

all_sports <- unique(c(as.character(FFtop_sports_data$Sport), as.character(LFtop_sports_data$Sport)))

colors <- setNames(rainbow(length(all_sports)), all_sports)


# 繪製四分位數圖
FFWplot <- plot_ly(FFtop_sports_data, y = ~Height, color = ~Sport, colors = colors, type = "box") %>%
  layout(title = "身高整體平均前五的運動的四分位數圖",
         yaxis = list(title = "身高 (cm)"),
         xaxis = list(title = "運動類型"))

LFWplot <- plot_ly(FFtop_sports_data, y = ~Height, color = ~Sport, colors = colors, type = "box") %>%
  layout(title = "身高整體平均後五的運動的四分位數圖",
         yaxis = list(title = "身高 (cm)"),
         xaxis = list(title = "運動類型"))


WHcombined_plot <- subplot(FFWplot, LFWplot, 
                           nrows = 1, # 一行
                           shareY = TRUE, # 共享Y轴
                           titleX = FALSE) # 不显示单独的x轴标题

# 调整布局
WHcombined_plot <- layout(WHcombined_plot,
                          title = "身高整體平均前五和後五的運動的四分位數圖",
                          xaxis = list(title = "前五"),
                          xaxis2 = list(title = "後五"),
                          yaxis = list(title = "身高 (cm)"))


#----------------



Sfiltered_data <- x %>%
  filter(!is.na(Height), Season == "Summer") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup()

# 計算IQR並去除極端值
Sfiltered_data <- Sfiltered_data %>%
  group_by(Sport) %>%
  mutate(HeightQ1 = quantile(Height, 0.25),
         HeightQ3 = quantile(Height, 0.75),
         HeightIQR = HeightQ3 - HeightQ1) %>%
  filter(Height >= (HeightQ1 - 1.5 * HeightIQR) & Height <= (HeightQ3 + 1.5 * HeightIQR)) %>%
  ungroup()

# 計算各運動的平均身高
FFStop_sports_by_height <- Sfiltered_data %>%
  group_by(Sport) %>%
  summarize(Average_Height = mean(Height, na.rm = TRUE)) %>%
  arrange(desc(Average_Height)) %>%
  slice_head(n = 5)  # 選出平均身高前五的運動

# 從原始數據中篩選出這些運動的數據
FFStop_sports_data <- Sfiltered_data %>%
  filter(Sport %in% FFStop_sports_by_height$Sport)



LFStop_sports_by_height <- Sfiltered_data %>%
  group_by(Sport) %>%
  summarize(Average_Height = mean(Height, na.rm = TRUE)) %>%
  arrange(Average_Height) %>%
  slice_head(n = 5)  # 選出平均身高前五的運動

# 從原始數據中篩選出這些運動的數據
LFStop_sports_data <- Sfiltered_data %>%
  filter(Sport %in% LFStop_sports_by_height$Sport)

all_sports <- unique(c(as.character(FFStop_sports_data$Sport), as.character(LFStop_sports_data$Sport)))

colors <- setNames(rainbow(length(all_sports)), all_sports)


# 繪製四分位數圖
FFSplot <- plot_ly(FFStop_sports_data, y = ~Height, color = ~Sport, colors = colors, type = "box") %>%
  layout(title = "身高整體平均前五的運動的四分位數圖",
         yaxis = list(title = "身高 (cm)"),
         xaxis = list(title = "運動類型"))

# 繪製四分位數圖
LFSplot <- plot_ly(LFStop_sports_data, y = ~Height, color = ~Sport, colors = colors, type = "box") %>%
  layout(title = "身高整體平均後五的運動的四分位數圖",
         yaxis = list(title = "身高 (cm)"),
         xaxis = list(title = "運動類型"))


SHcombined_plot <- subplot(FFSplot, LFSplot, 
                           nrows = 1, # 一行
                           shareY = TRUE, # 共享Y轴
                           titleX = FALSE) # 不显示单独的x轴标题

# 调整布局
SHcombined_plot <- layout(SHcombined_plot,
                          title = "身高整體平均前五和後五的運動的四分位數圖",
                          xaxis = list(title = "前五"),
                          xaxis2 = list(title = "後五"),
                          yaxis = list(title = "身高 (cm)"))


#---------------------------


#------------five Weight---------------

WWfiltered_data <- x %>%
  filter(!is.na(Weight), Season == "Winter") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup()

# 計算IQR並去除極端值
WWfiltered_data <- WWfiltered_data %>%
  group_by(Sport) %>%
  mutate(WeightQ1 = quantile(Weight, 0.25),
         WeightQ3 = quantile(Weight, 0.75),
         WeightIQR = WeightQ3 - WeightQ1) %>%
  filter(Weight >= (WeightQ1 - 1.5 * WeightIQR) & Weight <= (WeightQ3 + 1.5 * WeightIQR)) %>%
  ungroup()

# 計算各運動的平均身高
FFWtop_sports_by_Weight <- WWfiltered_data %>%
  group_by(Sport) %>%
  summarize(Average_Weight = mean(Weight, na.rm = TRUE)) %>%
  arrange(desc(Average_Weight)) %>%
  slice_head(n = 5)  # 選出平均身高前五的運動

# 從原始數據中篩選出這些運動的數據
FFWtop_sports_data <- WWfiltered_data %>%
  filter(Sport %in% FFWtop_sports_by_Weight$Sport)


LFWtop_sports_by_Weight <- WWfiltered_data %>%
  group_by(Sport) %>%
  summarize(Average_Weight = mean(Weight, na.rm = TRUE)) %>%
  arrange(Average_Weight) %>%
  slice_head(n = 5)  # 選出平均身高前五的運動

# 從原始數據中篩選出這些運動的數據
LFWtop_sports_data <- WWfiltered_data %>%
  filter(Sport %in% LFWtop_sports_by_Weight$Sport)

all_sports <- unique(c(as.character(FFWtop_sports_data$Sport), as.character(LFWtop_sports_data$Sport)))

colors <- setNames(rainbow(length(all_sports)), all_sports)

# 繪製四分位數圖
FFWWplot <- plot_ly(FFWtop_sports_data, y = ~Weight, color = ~Sport, colors = colors, type = "box") %>%
  layout(title = "體重整體平均前五的運動的四分位數圖",
         yaxis = list(title = "體重 (kg)"),
         xaxis = list(title = "運動類型"))

LFWWplot <- plot_ly(FFWtop_sports_data, y = ~Weight, color = ~Sport, colors = colors, type = "box") %>%
  layout(title = "體重整體平均後五的運動的四分位數圖",
         yaxis = list(title = "體重 (kg)"),
         xaxis = list(title = "運動類型"))

WWcombined_plot <- subplot(FFWWplot, LFWWplot, 
                           nrows = 1, # 一行
                           shareY = TRUE, # 共享Y轴
                           titleX = FALSE) # 不显示单独的x轴标题

# 调整布局
WWcombined_plot <- layout(WWcombined_plot,
                          title = "體重整體平均前五和後五的運動的四分位數圖",
                          xaxis = list(title = "前五"),
                          xaxis2 = list(title = "後五"),
                          yaxis = list(title = "體重 (kg)"))


#--------last five weight-----



SWfiltered_data <- x %>%
  filter(!is.na(Weight), Season == "Summer") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup()

# 計算IQR並去除極端值
SWfiltered_data <- SWfiltered_data %>%
  group_by(Sport) %>%
  mutate(WeightQ1 = quantile(Weight, 0.25),
         WeightQ3 = quantile(Weight, 0.75),
         WeightIQR = WeightQ3 - WeightQ1) %>%
  filter(Weight >= (WeightQ1 - 1.5 * WeightIQR) & Weight <= (WeightQ3 + 1.5 * WeightIQR)) %>%
  ungroup()

# 計算各運動的平均身高
FFSWtop_sports_by_Weight <- SWfiltered_data %>%
  group_by(Sport) %>%
  summarize(Average_Weight = mean(Weight, na.rm = TRUE)) %>%
  arrange(desc(Average_Weight)) %>%
  slice_head(n = 5)  # 選出平均身高前五的運動

# 從原始數據中篩選出這些運動的數據
FFSWtop_sports_data <- SWfiltered_data %>%
  filter(Sport %in% FFSWtop_sports_by_Weight$Sport)



LFSWtop_sports_by_Weight <- SWfiltered_data %>%
  group_by(Sport) %>%
  summarize(Average_Weight = mean(Weight, na.rm = TRUE)) %>%
  arrange(Average_Weight) %>%
  slice_head(n = 5)  # 選出平均身高前五的運動

# 從原始數據中篩選出這些運動的數據
LFSWtop_sports_data <- SWfiltered_data %>%
  filter(Sport %in% LFSWtop_sports_by_Weight$Sport)

all_sports <- unique(c(as.character(FFSWtop_sports_data$Sport), as.character(LFSWtop_sports_data$Sport)))

colors <- setNames(rainbow(length(all_sports)), all_sports)


# 繪製四分位數圖
FFSWplot <- plot_ly(FFSWtop_sports_data, y = ~Weight, color = ~Sport, colors = colors, type = "box") %>%
  layout(title = "體重整體平均前五的運動的四分位數圖",
         yaxis = list(title = "體重 (kg)"),
         xaxis = list(title = "運動類型"))
# 繪製四分位數圖
LFSWplot <- plot_ly(LFSWtop_sports_data, y = ~Weight, color = ~Sport, colors = colors, type = "box") %>%
  layout(title = "體重整體平均後五的運動的四分位數圖",
         yaxis = list(title = "體重 (kg)"),
         xaxis = list(title = "運動類型"))



SWcombined_plot <- subplot(FFSWplot, LFSWplot, 
                         nrows = 1, # 一行
                         shareY = TRUE, # 共享Y轴
                         titleX = FALSE) # 不显示单独的x轴标题

# 调整布局
SWcombined_plot <- layout(SWcombined_plot,
                        title = "體重整體平均前五和後五的運動的四分位數圖",
                        xaxis = list(title = "前五"),
                        xaxis2 = list(title = "後五"),
                        yaxis = list(title = "體重 (kg)"))





