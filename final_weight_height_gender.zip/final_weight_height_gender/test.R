x = read.csv("athlete_events.csv", stringsAsFactors = FALSE)

summerSport = unique(x %>% filter(Season == "Summer") %>% select(Sport))
# 季節、運動、性別
# test
df <- x %>% filter(Sport == "Diving", Games == "Summer") 
df



filtered_data <- x %>%
  filter(Sport == "Football", !is.na(Height), !is.na(Weight)) %>%
  group_by(ID) %>%
  # 對每位選手選取最新年份的記錄
  filter(Year == max(Year)) %>%
  # 若同年份有多條記錄，僅保留第一筆
  slice(1) %>%
  ungroup() %>%
  # 選取所需的欄位
  select(Name, Sex, Age, Height, Weight)

filtered_data

data <- filtered_data

# 使用plotly創建身高的四分位數圖
height_plot <- plot_ly(data, y = ~Height, type = "box", name = "身高") %>%
  layout(title = "身高的四分位數圖",
         yaxis = list(title = "身高 (cm)"))

# 使用plotly創建體重的四分位數圖
weight_plot <- plot_ly(data, y = ~Weight, type = "box", name = "體重") %>%
  layout(title = "體重的四分位數圖",
         yaxis = list(title = "體重 (kg)"))

# 顯示身高圖表
height_plot

# 顯示體重圖表
weight_plot


# 創建身高的四分位數圖
height_plot <- plot_ly(data, y = ~Height, type = "box", name = "身高") %>%
  layout(title = "身高")

# 創建體重的四分位數圖
weight_plot <- plot_ly(data, y = ~Weight, type = "box", name = "體重") %>%
  layout(title = "體重")

# 使用subplot函數合併圖表
combined_plot <- subplot(height_plot, weight_plot, nrows = 1, shareX = TRUE, shareY = FALSE) %>%
  layout(title = "身高和體重的四分位數圖")

# 顯示合併後的圖表
combined_plot







filtered_data <- x %>%
  filter(Sport == "Football", !is.na(Height), !is.na(Weight)) %>%
  group_by(ID) %>%
  # 對每位選手選取最新年份的記錄
  filter(Year == max(Year)) %>%
  # 若同年份有多條記錄，僅保留第一筆
  slice(1) %>%
  ungroup() %>%
  # 選取所需的欄位
  select(Name, Sex, Age, Height, Weight)


filtered_data <- x %>% filter(!is.na(Height), Season == "Summer") %>%
  group_by(ID) %>%
  filter(Year == max(Year)) %>%
  slice(1) %>%
  ungroup() 

# 使用plotly創建分組盒形圖，每個運動一組
plot <- plot_ly(filtered_data, y = ~Height, color = ~Sport, type = "box") %>%
  layout(title = "各運動選手身高的四分位數圖",
         yaxis = list(title = "身高 (cm)"),
         xaxis = list(title = "運動類型"),
         boxmode = "group")

# 顯示圖表
plot

