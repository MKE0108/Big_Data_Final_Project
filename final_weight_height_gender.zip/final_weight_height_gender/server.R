library(shiny)
library(plotly)

server <- function(input, output, session) {
  output$dynamicSelect <- renderUI({
    if(input$unit == "selectS"){
      summerSport = unique(x %>% filter(Season == "Summer") %>% select(Sport))
      winterSport = unique(x %>% filter(Season == "Winter") %>% select(Sport))
      if(input$seasonSelect == "Summer") {
        selectInput("dynamicInput", "Select Sport:",
                    choices = summerSport)
      } else {
        selectInput("dynamicInput", "Select Sport:",
                    choices = winterSport)
      } 
    }
  })
  
  output$main <- renderUI({
    if (input$unit == "selectS") {
      tagList(
        plotlyOutput("genderPlot"),
        plotlyOutput("seasonPlot")
      )
    } else if (input$unit == "five") {
      tagList(
        plotlyOutput("genderPlot"),
        plotlyOutput("fivePlot"),
        plotlyOutput("fivePlot2")
      )
    } else {
      tagList(
        plotlyOutput("genderPlot"),
        plotlyOutput("allPlot"),
        plotlyOutput("allPlot2")
      )
    }
  })
  
  output$fivePlot <- renderPlotly({
    if(input$seasonSelect == "Summer"){
      SHcombined_plot
    }else{
      WHcombined_plot
    }
  })
  output$fivePlot2 <- renderPlotly({
    if(input$seasonSelect == "Summer"){
      SWcombined_plot
    }else{
      WWcombined_plot
    }
  })
  
  output$allPlot <- renderPlotly({
    if(input$seasonSelect == "Summer"){
      ASHplot
    }else{
      AWHplot
    }
  })
  output$allPlot2 <- renderPlotly({
    if(input$seasonSelect == "Summer"){
      ASWplot
    }else{
      AWWplot
    }
  })

  output$seasonPlot <- renderPlotly({
    filtered_data <- x %>%
      filter(Sport == input$dynamicInput, Season == input$seasonSelect, !is.na(Height), !is.na(Weight)) %>%
      group_by(ID) %>%
      filter(Year == max(Year)) %>%
      slice(1) %>%
      ungroup() %>%
      select(Name, Sex, Age, Height, Weight) %>%
      # 計算IQR並去除極端值
      mutate(HeightQ1 = quantile(Height, 0.25),
             HeightQ3 = quantile(Height, 0.75),
             HeightIQR = HeightQ3 - HeightQ1,
             WeightQ1 = quantile(Weight, 0.25),
             WeightQ3 = quantile(Weight, 0.75),
             WeightIQR = WeightQ3 - WeightQ1) %>%
      filter(Height >= (HeightQ1 - 1.5 * HeightIQR) & Height <= (HeightQ3 + 1.5 * HeightIQR),
             Weight >= (WeightQ1 - 1.5 * WeightIQR) & Weight <= (WeightQ3 + 1.5 * WeightIQR))
    data <- filtered_data
    # 身高四分位數圖
    height_plot <- plot_ly(data, y = ~Height, type = "box", name = "身高") %>%
      layout(title = "身高")
    
    # 體重四分位數圖
    weight_plot <- plot_ly(data, y = ~Weight, type = "box", name = "體重") %>%
      layout(title = "體重")
    # 合併圖表
    combined_plot <- subplot(height_plot, weight_plot, nrows = 1, shareX = TRUE, shareY = FALSE) %>%
      layout(title = "身高和體重的四分位數圖")
    combined_plot
  })
  output$genderPlot <- renderPlotly({
    if(input$unit == "selectS"){
      filtered_data <- x %>%
        filter(Sport == input$dynamicInput, Season == input$seasonSelect, !is.na(Height), !is.na(Weight)) %>%
        group_by(ID) %>%
        filter(Year == max(Year)) %>%
        slice(1) %>%
        ungroup() %>%
        select(Name, Sex, Age, Height, Weight)
      
      data <- filtered_data
      gender_counts <- table(data$Sex)
      
      gender_pie <- plot_ly(labels = names(gender_counts), values = as.numeric(gender_counts), type = 'pie',
                            marker = list(colors = c('#FF9999','#66b3ff')), # 自訂顏色，例如粉色和藍色
                            textinfo = 'label+percent',
                            insidetextorientation = 'radial')
      gender_pie <- gender_pie %>% layout(title = '性別比例圓餅圖')
      gender_pie
    }else{
      filtered_data <- x %>% filter(!is.na(Height), Season == input$seasonSelect) %>%
        group_by(ID) %>%
        filter(Year == max(Year)) %>%
        slice(1) %>%
        ungroup() 
      data <- filtered_data
      gender_counts <- table(data$Sex)
      
      gender_pie <- plot_ly(labels = names(gender_counts), values = as.numeric(gender_counts), type = 'pie',
                            marker = list(colors = c('#FF9999','#66b3ff')), # 自訂顏色，例如粉色和藍色
                            textinfo = 'label+percent',
                            insidetextorientation = 'radial')
      gender_pie <- gender_pie %>% layout(title = '性別比例圓餅圖')
      gender_pie
    }
    
  })
}

